using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using HRManagementSystem.Data;
using HRManagementSystem.Repositories;
using HRManagementSystem.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);


// ✅ DATABASE CONNECTION
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


// ✅ DEPENDENCY INJECTION
builder.Services.AddScoped<EmployeeRepository>();
builder.Services.AddScoped<EmployeeService>();

builder.Services.AddScoped<LeaveRepository>();
builder.Services.AddScoped<LeaveService>();


// ✅ CORS (for React frontend)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy => policy
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());
});


// ✅ CONTROLLERS + SWAGGER
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


// ✅ BUILD APP
var app = builder.Build();


// ✅ USE CORS (AFTER BUILD)
app.UseCors("AllowAll");


// ✅ SWAGGER (only in development)
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


// ✅ MIDDLEWARE
app.UseAuthorization();


// ✅ MAP CONTROLLERS
app.MapControllers();


// ✅ RUN APP
app.Run();
