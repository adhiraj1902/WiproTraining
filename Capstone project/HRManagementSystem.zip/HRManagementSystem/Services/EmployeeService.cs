using HRManagementSystem.Models;
using HRManagementSystem.Repositories;

namespace HRManagementSystem.Services
{
    public class EmployeeService
    {
        private readonly EmployeeRepository _repo;

        public EmployeeService(EmployeeRepository repo)
        {
            _repo = repo;
        }

        public List<Employee> GetEmployees()
        {
            return _repo.GetEmployees();
        }

        // ✅ ADD
        public void AddEmployee(Employee employee)
        {
            _repo.AddEmployee(employee);
        }

        // ✅ UPDATE
        public void UpdateEmployee(int id, Employee employee)
        {
            _repo.UpdateEmployee(id, employee);
        }

        // ✅ DELETE
        public void DeleteEmployee(int id)
        {
            _repo.DeleteEmployee(id);
        }
    }
}