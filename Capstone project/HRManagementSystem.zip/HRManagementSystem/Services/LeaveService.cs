using HRManagementSystem.Models;
using HRManagementSystem.Repositories;

namespace HRManagementSystem.Services
{
    public class LeaveService
    {
        private readonly LeaveRepository repository = new LeaveRepository();

        //  REQUEST LEAVE WITH VALIDATION
        public string RequestLeave(LeaveRequest leave)
        {
            if (leave.StartDate > leave.EndDate)
            {
                return "Start date cannot be after end date.";
            }

            int leaveDays = (leave.EndDate - leave.StartDate).Days + 1;

            int balance = repository.GetLeaveBalance(leave.EmployeeId);

            if (balance < leaveDays)
            {
                return "Insufficient leave balance.";
            }

            repository.RequestLeave(leave);

            return "Leave request submitted successfully.";
        }

        //  GET ALL LEAVES
        public List<LeaveRequest> GetLeaves()
        {
            return repository.GetLeaves();
        }

        //  APPROVE
        public void ApproveLeave(int leaveId)
        {
            repository.ApproveLeave(leaveId);
        }

        //  REJECT
        public void RejectLeave(int leaveId)
        {
            repository.RejectLeave(leaveId);
        }

        //  GET BALANCE
        public int GetLeaveBalance(int employeeId)
        {
            return repository.GetLeaveBalance(employeeId);
        }
    }
}