using HRManagementSystem.Repositories;

namespace HRManagementSystem.Services
{
    public class AnalyticsService
    {
        private readonly AnalyticsRepository repository = new AnalyticsRepository();

        public object GetDepartmentHeadcount()
        {
            return repository.GetDepartmentHeadcount();
        }

        public object GetLeaveSummary()
        {
            return repository.GetLeaveSummary();
        }

        public object GetWorkforceOverview()
        {
            return repository.GetWorkforceOverview();
        }
    }
}