using System.ComponentModel.DataAnnotations;

namespace HRManagementSystem.Models
{
    public class LeaveRequest
    {
        [Key]
        public int LeaveId { get; set; } //  match DB

        public int EmployeeId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string Status { get; set; } = "Pending";
    }
}