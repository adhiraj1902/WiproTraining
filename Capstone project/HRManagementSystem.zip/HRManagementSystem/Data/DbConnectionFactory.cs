using Microsoft.Data.SqlClient;

namespace HRManagementSystem.Data
{
    public class DbConnectionFactory
    {
       private readonly string connectionString =
                        "Server=(localdb)\\MSSQLLocalDB;Database=HRManagementDB;Trusted_Connection=True;";

        public SqlConnection CreateConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}