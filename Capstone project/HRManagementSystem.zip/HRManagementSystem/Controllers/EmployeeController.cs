using Microsoft.AspNetCore.Mvc;
using HRManagementSystem.Services;
using HRManagementSystem.Models;

namespace HRManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly EmployeeService _service;

        public EmployeeController(EmployeeService service)
        {
            _service = service;
        }

        //  GET
        [HttpGet]
        public IActionResult GetEmployees()
        {
            var data = _service.GetEmployees();
            return Ok(data);
        }

        //  POST
        [HttpPost]
        public IActionResult AddEmployee(Employee employee)
        {
            _service.AddEmployee(employee);
            return Ok(employee);
        }

        //  PUT
        [HttpPut("{id}")]
        public IActionResult UpdateEmployee(int id, Employee employee)
        {
            _service.UpdateEmployee(id, employee);
            return Ok();
        }

        //  DELETE
        [HttpDelete("{id}")]
        public IActionResult DeleteEmployee(int id)
        {
            _service.DeleteEmployee(id);
            return Ok();
        }
    }
}