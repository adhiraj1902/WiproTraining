using Microsoft.AspNetCore.Mvc;
using HRManagementSystem.Services;

namespace HRManagementSystem.Controllers
{
    [ApiController]
    [Route("api/analytics")]
    public class AnalyticsController : ControllerBase
    {
        private readonly AnalyticsService service = new AnalyticsService();

        [HttpGet("department-headcount")]
        public IActionResult DepartmentHeadcount()
        {
            return Ok(service.GetDepartmentHeadcount());
        }

        [HttpGet("leave-summary")]
        public IActionResult LeaveSummary()
        {
            return Ok(service.GetLeaveSummary());
        }

        [HttpGet("workforce-overview")]
        public IActionResult WorkforceOverview()
        {
            return Ok(service.GetWorkforceOverview());
        }
    }
}