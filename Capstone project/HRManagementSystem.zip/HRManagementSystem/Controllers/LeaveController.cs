using Microsoft.AspNetCore.Mvc;
using HRManagementSystem.Models;
using HRManagementSystem.Services;

namespace HRManagementSystem.Controllers
{
    [ApiController]
    [Route("api/leave")]
    public class LeaveController : ControllerBase
    {
        private readonly LeaveService service = new LeaveService();

       [HttpPost("request")]
public IActionResult RequestLeave(LeaveRequest leave)
{
    var result = service.RequestLeave(leave);

    return Ok(result);
}

        [HttpGet]
        public IActionResult GetLeaves()
        {
            var leaves = service.GetLeaves();
            return Ok(leaves);
        }

   [HttpPut("approve/{id}")]
public IActionResult ApproveLeave(int id)
{
    service.ApproveLeave(id);
    return Ok("Leave Approved");
}

[HttpPut("reject/{id}")]
public IActionResult RejectLeave(int id)
{
    service.RejectLeave(id);
    return Ok("Leave Rejected");
}

[HttpGet("balance/{employeeId}")]
public IActionResult GetLeaveBalance(int employeeId)
{
    var balance = service.GetLeaveBalance(employeeId);
    return Ok(balance);
}
    }
}