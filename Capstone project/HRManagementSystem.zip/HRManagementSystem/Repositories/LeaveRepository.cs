using HRManagementSystem.Models;
using HRManagementSystem.Data;
using Microsoft.Data.SqlClient;

namespace HRManagementSystem.Repositories
{
    public class LeaveRepository
    {
        private readonly DbConnectionFactory db = new DbConnectionFactory();

        // ✅ REQUEST LEAVE
        public void RequestLeave(LeaveRequest leave)
        {
            using (SqlConnection conn = db.CreateConnection())
            {
                conn.Open();

                string query = @"INSERT INTO LeaveRequests 
                                (EmployeeId, StartDate, EndDate, Status)
                                VALUES (@EmployeeId, @StartDate, @EndDate, 'Pending')";

                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@EmployeeId", leave.EmployeeId);
                cmd.Parameters.AddWithValue("@StartDate", leave.StartDate);
                cmd.Parameters.AddWithValue("@EndDate", leave.EndDate);

                cmd.ExecuteNonQuery();
            }
        }

        // ✅ GET ALL LEAVES
        public List<LeaveRequest> GetLeaves()
        {
            List<LeaveRequest> leaves = new List<LeaveRequest>();

            using (SqlConnection conn = db.CreateConnection())
            {
                conn.Open();

                string query = "SELECT * FROM LeaveRequests";

                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    LeaveRequest leave = new LeaveRequest
                    {
                        LeaveId = (int)reader["LeaveId"],
                        EmployeeId = (int)reader["EmployeeId"],
                        StartDate = (DateTime)reader["StartDate"],
                        EndDate = (DateTime)reader["EndDate"],
                        Status = reader["Status"].ToString(),
                    };

                    leaves.Add(leave);
                }
            }

            return leaves;
        }

        // ✅ GET LEAVE BALANCE (ONLY ONE METHOD)
        public int GetLeaveBalance(int employeeId)
        {
            using (SqlConnection conn = db.CreateConnection())
            {
                conn.Open();

                string query = "SELECT LeaveBalance FROM Employees WHERE EmployeeId = @EmployeeId";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);

                var result = cmd.ExecuteScalar();

                return result != null ? Convert.ToInt32(result) : 0;
            }
        }

        // ✅ APPROVE LEAVE
        public void ApproveLeave(int leaveId)
        {
            using (SqlConnection conn = db.CreateConnection())
            {
                conn.Open();

                // Get leave request
                string getLeaveQuery = @"SELECT EmployeeId, 
                                        DATEDIFF(day, StartDate, EndDate)+1 AS Days 
                                        FROM LeaveRequests 
                                        WHERE LeaveId=@LeaveId";

                SqlCommand getCmd = new SqlCommand(getLeaveQuery, conn);
                getCmd.Parameters.AddWithValue("@LeaveId", leaveId);

                SqlDataReader reader = getCmd.ExecuteReader();

                int employeeId = 0;
                int days = 0;

                if (reader.Read())
                {
                    employeeId = (int)reader["EmployeeId"];
                    days = (int)reader["Days"];
                }

                reader.Close();

                // Update leave status
                string updateLeave = "UPDATE LeaveRequests SET Status='Approved' WHERE LeaveId=@LeaveId";

                SqlCommand updateCmd = new SqlCommand(updateLeave, conn);
                updateCmd.Parameters.AddWithValue("@LeaveId", leaveId);
                updateCmd.ExecuteNonQuery();

                // Deduct leave balance
                string deductQuery = @"UPDATE Employees 
                                       SET LeaveBalance = LeaveBalance - @Days 
                                       WHERE EmployeeId=@EmployeeId";

                SqlCommand deductCmd = new SqlCommand(deductQuery, conn);
                deductCmd.Parameters.AddWithValue("@Days", days);
                deductCmd.Parameters.AddWithValue("@EmployeeId", employeeId);

                deductCmd.ExecuteNonQuery();
            }
        }

        // ✅ REJECT LEAVE
        public void RejectLeave(int leaveId)
        {
            using (SqlConnection conn = db.CreateConnection())
            {
                conn.Open();

                string query = "UPDATE LeaveRequests SET Status='Rejected' WHERE LeaveId=@LeaveId";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@LeaveId", leaveId);

                cmd.ExecuteNonQuery();
            }
        }
    }
}