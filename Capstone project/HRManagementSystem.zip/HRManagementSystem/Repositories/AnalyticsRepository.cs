using Microsoft.Data.SqlClient;
using HRManagementSystem.Data;

namespace HRManagementSystem.Repositories
{
    public class AnalyticsRepository
    {
        private readonly DbConnectionFactory db = new DbConnectionFactory();

        public List<object> GetDepartmentHeadcount()
        {
            List<object> result = new List<object>();

            using (SqlConnection conn = db.CreateConnection())
            {
                conn.Open();

                string query = @"
                SELECT DepartmentId, COUNT(*) AS TotalEmployees
                FROM Employees
                GROUP BY DepartmentId";

                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    result.Add(new
                    {
                        DepartmentId = (int)reader["DepartmentId"],
                        TotalEmployees = (int)reader["TotalEmployees"]
                    });
                }
            }

            return result;
        }

        public List<object> GetLeaveSummary()
        {
            List<object> result = new List<object>();

            using (SqlConnection conn = db.CreateConnection())
            {
                conn.Open();

                string query = @"
                SELECT Status, COUNT(*) AS Total
                FROM LeaveRequests
                GROUP BY Status";

                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    result.Add(new
                    {
                        Status = reader["Status"].ToString(),
                        Total = (int)reader["Total"]
                    });
                }
            }

            return result;
        }

        public object GetWorkforceOverview()
        {
            using (SqlConnection conn = db.CreateConnection())
            {
                conn.Open();

                string employeeQuery = "SELECT COUNT(*) FROM Employees";
                string leaveQuery = "SELECT COUNT(*) FROM LeaveRequests";

                SqlCommand empCmd = new SqlCommand(employeeQuery, conn);
                SqlCommand leaveCmd = new SqlCommand(leaveQuery, conn);

                int totalEmployees = (int)empCmd.ExecuteScalar();
                int totalLeaves = (int)leaveCmd.ExecuteScalar();

                return new
                {
                    TotalEmployees = totalEmployees,
                    TotalLeaveRequests = totalLeaves
                };
            }
        }
    }
}