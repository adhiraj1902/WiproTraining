using HRManagementSystem.Data;
using HRManagementSystem.Models;

namespace HRManagementSystem.Repositories
{
    public class EmployeeRepository
    {
        private readonly ApplicationDbContext _context;

        public EmployeeRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        //  GET
        public List<Employee> GetEmployees()
        {
            return _context.Employees.ToList();
        }

        //  ADD
        public void AddEmployee(Employee employee)
        {
            _context.Employees.Add(employee);
            _context.SaveChanges();
        }

        //  UPDATE
        public void UpdateEmployee(int id, Employee updatedEmployee)
        {
            var emp = _context.Employees.Find(id);

            if (emp != null)
            {
                emp.FirstName = updatedEmployee.FirstName;
                emp.LastName = updatedEmployee.LastName;
                emp.Email = updatedEmployee.Email;
                emp.DepartmentId = updatedEmployee.DepartmentId;
                emp.LeaveBalance = updatedEmployee.LeaveBalance;

                _context.SaveChanges();
            }
        }

        //  DELETE
        public void DeleteEmployee(int id)
        {
            var emp = _context.Employees.Find(id);

            if (emp != null)
            {
                _context.Employees.Remove(emp);
                _context.SaveChanges();
            }
        }
    }
}