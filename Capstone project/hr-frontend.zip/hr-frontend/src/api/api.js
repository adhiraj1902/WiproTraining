import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5230/api"
});

export default API;