import { Routes, Route, Navigate } from "react-router-dom";

import Sidebar from "./components/Sidebar";

import Dashboard from "./pages/Dashboard";
import Employees from "./pages/Employees";
import Leaves from "./pages/Leaves";
import Login from "./pages/Login";
import EmployeeLeave from "./pages/EmployeeLeave";
import EmployeeDashboard from "./pages/EmployeeDashboard";
import ApplyLeave from "./pages/ApplyLeave";

function App() {

  const user = localStorage.getItem("user");

  // ❌ Not logged in
  if (!user) return <Login />;

  // 👨‍💻 EMPLOYEE VIEW
if (user === "employee") {
  return (
    <div style={{ display: "flex" }}>
      
      {/* ✅ SIDEBAR ADDED */}
      <Sidebar />

      <div style={{ flex: 1, padding: "20px" }}>
        <Routes>
          <Route path="/employee" element={<EmployeeDashboard />} />
          <Route path="/employee/apply" element={<ApplyLeave />} />
          <Route path="*" element={<Navigate to="/employee" />} />
        </Routes>
      </div>

    </div>
  );
}

  // 👨‍💼 HR VIEW
  return (
    <div style={{ display: "flex" }}>
      
      <Sidebar />

      <div style={{ flex: 1, padding: "20px" }}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/employees" element={<Employees />} />
          <Route path="/leaves" element={<Leaves />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>

    </div>
  );
}

export default App;