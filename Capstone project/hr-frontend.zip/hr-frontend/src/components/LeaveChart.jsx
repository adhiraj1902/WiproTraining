import { useEffect, useState } from "react";
import API from "../api/api";
import { PieChart, Pie, Cell, Tooltip, Legend } from "recharts";

function LeaveChart(){

  const [data,setData] = useState([]);

  useEffect(()=>{

    API.get("/analytics/leave-summary")
      .then(res=>setData(res.data));

  },[]);

  const COLORS = ["#10b981","#f59e0b","#ef4444"];

  return(

    <div style={{marginTop:"40px"}}>

      <h2>Leave Distribution</h2>

      <PieChart width={400} height={300}>

        <Pie
          data={data}
          dataKey="total"
          nameKey="status"
          outerRadius={100}
          label
        >

          {data.map((entry,index)=>(
            <Cell key={index} fill={COLORS[index%COLORS.length]} />
          ))}

        </Pie>

        <Tooltip />
        <Legend />

      </PieChart>

    </div>

  );
}

export default LeaveChart;