import { useNavigate, useLocation } from "react-router-dom";

function Sidebar() {

  const navigate = useNavigate();
  const location = useLocation();

  const user = localStorage.getItem("user");
  const name = localStorage.getItem("empName") || "HR User";

  const logout = () => {
    localStorage.clear();
    navigate("/login");
    window.location.reload();
  };

  // 🔥 ACTIVE STYLE FUNCTION
  const isActive = (path) => {
    return location.pathname === path ? styles.active : {};
  };

  return (
    <div style={styles.sidebar}>

      <h2 style={{ marginBottom: "10px" }}>HRMS</h2>

      <h3 style={{ marginTop: "10px", fontSize: "16px", opacity: 0.8 }}>
        {name}
      </h3>

      <ul style={styles.menu}>

        {/* ================= HR MENU ================= */}
        {user === "hr" && (
          <>
            <li
              style={{ ...styles.item, ...isActive("/") }}
              onClick={() => navigate("/")}
            >
              Dashboard
            </li>

            <li
              style={{ ...styles.item, ...isActive("/employees") }}
              onClick={() => navigate("/employees")}
            >
              Employees
            </li>

            <li
              style={{ ...styles.item, ...isActive("/leaves") }}
              onClick={() => navigate("/leaves")}
            >
              Leaves
            </li>
          </>
        )}

        {/* ================= EMPLOYEE MENU ================= */}
        {user === "employee" && (
          <>
            <li
              style={{ ...styles.item, ...isActive("/employee") }}
              onClick={() => navigate("/employee")}
            >
              Dashboard
            </li>

            <li
              style={{ ...styles.item, ...isActive("/employee/profile") }}
              onClick={() => navigate("/employee/profile")}
            >
              Profile
            </li>

            <li
              style={{ ...styles.item, ...isActive("/employee/apply") }}
              onClick={() => navigate("/employee/apply")}
            >
              Apply Leave
            </li>
          </>
        )}

        {/* ================= LOGOUT ================= */}
        <li
          onClick={logout}
          style={{ ...styles.item, marginTop: "30px", color: "#ff4d4d" }}
        >
          Logout
        </li>

      </ul>

    </div>
  );
}

/* ================= STYLES ================= */

const styles = {
  sidebar: {
    width: "230px",
    background: "linear-gradient(180deg, #2c2f48, #1e2135)",
    color: "white",
    padding: "20px",
    height: "100vh",
    boxShadow: "2px 0 10px rgba(0,0,0,0.2)"
  },

  menu: {
    listStyle: "none",
    padding: 0,
    marginTop: "30px"
  },

  item: {
    padding: "12px 10px",
    marginBottom: "10px",
    cursor: "pointer",
    borderRadius: "8px",
    transition: "0.3s",
  },

  active: {
    background: "#4c6fff",
    fontWeight: "bold"
  }
};

export default Sidebar;