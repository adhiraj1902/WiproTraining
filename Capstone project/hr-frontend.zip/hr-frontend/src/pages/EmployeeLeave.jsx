import { useEffect, useState } from "react";
import API from "../api/api";
import { useNavigate } from "react-router-dom";

function EmployeeLeave() {

  const [leaves, setLeaves] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [leaveBalance, setLeaveBalance] = useState(0);

  const empId = localStorage.getItem("empId");
  const empName = localStorage.getItem("empName");
  const empEmail = localStorage.getItem("empEmail");

  const navigate = useNavigate();

  // 🔄 Load data
  useEffect(() => {
    loadLeaves();
    loadBalance();
  }, []);

  // ✅ GET LEAVES
  const loadLeaves = async () => {
    try {
      const res = await API.get("/leave");
      const myLeaves = res.data.filter(l => l.employeeId == empId);
      setLeaves(myLeaves);
    } catch (err) {
      console.error(err);
    }
  };

  // ✅ GET LEAVE BALANCE
  const loadBalance = async () => {
    try {
      const res = await API.get(`/leave/balance/${empId}`);
      setLeaveBalance(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // ✅ LOGOUT
  const logout = () => {
    localStorage.clear();
    navigate("/login");
    window.location.reload();
  };

  // ✅ APPLY LEAVE
  const applyLeave = async () => {

    if (!startDate || !endDate) {
      alert("Select dates");
      return;
    }

    try {
      await API.post("/leave/request", {
        employeeId: parseInt(empId),
        startDate,
        endDate
      });

      alert("Leave Applied");

      loadLeaves();
      loadBalance(); //  update balance
    } catch (err) {
      console.error(err);
    }
  };

  return (

    <div style={{ padding: "20px" }}>

      {/*  HEADER WITH LOGOUT */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>Employee Leave Portal</h2>

        <button onClick={logout}>
          Logout
        </button>
      </div>

      {/*  EMPLOYEE DETAILS */}
      <h4>ID: {empId}</h4>
      <h4>Name: {empName}</h4>
      <h4>Email: {empEmail}</h4>
      <h4>Leave Balance: {leaveBalance}</h4>

      <br />

      {/*  APPLY LEAVE */}
      <h3>Apply Leave</h3>

      <input
        type="date"
        onChange={(e) => setStartDate(e.target.value)}
      />

      <input
        type="date"
        onChange={(e) => setEndDate(e.target.value)}
      />

      <button onClick={applyLeave}>
        Apply
      </button>

      <br /><br />

      {/*  LEAVE TABLE */}
      <h3>My Leave Requests</h3>

      <table border="1" cellPadding="10">

        <thead>
          <tr>
            <th>ID</th>
            <th>Start</th>
            <th>End</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          {leaves.map((l) => (
            <tr key={l.leaveId}>
              <td>{l.leaveId}</td>
              <td>{l.startDate}</td>
              <td>{l.endDate}</td>
              <td>{l.status}</td>
            </tr>
          ))}
        </tbody>

      </table>

    </div>
  );
}

export default EmployeeLeave;