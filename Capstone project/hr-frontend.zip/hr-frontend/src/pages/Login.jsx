import { useState } from "react";
import "./login.css";

function Login() {

  const [role, setRole] = useState("hr"); // hr | employee
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const login = () => {

  // HR LOGIN
  if (role === "hr") {
    if (email === "hr" && password === "1234") {
      localStorage.setItem("user", "hr");
      window.location.href = "/";
    } else {
      alert("Invalid HR credentials");
    }
  }

  // EMPLOYEE LOGIN
  else {
    if (email === "emp" && password === "1234") {
      localStorage.setItem("user", "employee");

      localStorage.setItem("empId", 3);
      localStorage.setItem("empName", "Adhiraj deshmukh");
      localStorage.setItem("empEmail", "adhiraj@email.com");

      //  ADD THIS LINE HERE
      window.location.href = "/employee";

    } else {
      alert("Invalid Employee credentials");
    }
  }
};

  return (
    <div className="login-container">

      {/* LEFT PANEL */}
      <div className="login-left">
        <h1>HRMS</h1>

        <div className="avatar"></div>

        <h2>Sign In</h2>

        {/* ROLE SWITCH */}
        <div className="role-switch">
          <span
            className={role === "hr" ? "active" : ""}
            onClick={() => setRole("hr")}
          >
            HR
          </span>

          <span
            className={role === "employee" ? "active" : ""}
            onClick={() => setRole("employee")}
          >
            Employee
          </span>
        </div>

        {/* INPUTS */}
        <input
          placeholder={role === "hr" ? "HR Username" : "Employee Username"}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={login}>
          Sign In
        </button>

      </div>

      {/* RIGHT PANEL */}
      <div className="login-right">
        <img
          src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
          alt="illustration"
        />
        <h2>
          {role === "hr"
            ? "Manage Employees & Leaves"
            : "Apply & Track Your Leaves"}
        </h2>
      </div>

    </div>
  );
}

export default Login;