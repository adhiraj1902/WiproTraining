import { useEffect, useState } from "react";
import API from "../api/api";

function Dashboard() {
  const [employees, setEmployees] = useState([]);
  const [leaves, setLeaves] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const empRes = await API.get("/employee");
      const leaveRes = await API.get("/leave");

      setEmployees(empRes.data);
      setLeaves(leaveRes.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <h1>Dashboard</h1>

      <div style={{ display: "flex", gap: "20px" }}>
        <div style={{ background: "#4f8ef7", padding: "20px", color: "white" }}>
          <h3>Total Employees</h3>
          <h2>{employees.length}</h2>
        </div>

        <div style={{ background: "#22c55e", padding: "20px", color: "white" }}>
          <h3>Total Leaves</h3>
          <h2>{leaves.length}</h2>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;