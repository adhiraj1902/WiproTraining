import { useEffect,useState } from "react";
import API from "../api/api";


function Leaves(){

const [employeeId,setEmployeeId]=useState("");
const [startDate,setStartDate]=useState("");
const [endDate,setEndDate]=useState("");

const [leaves,setLeaves]=useState([]);

useEffect(()=>{
loadLeaves();
},[])

const loadLeaves=async()=>{

const res=await API.get("/leave");
setLeaves(res.data);

}

const applyLeave=async()=>{

await API.post("/leave/request",{
employeeId:parseInt(employeeId),
startDate:startDate,
endDate:endDate,
status:"Pending"
})

loadLeaves();

}

const approveLeave = async (id) => {
  try {
    await API.put(`/leave/approve/${id}`);
    loadLeaves(); //  refresh
  } catch (err) {
    console.error(err);
  }
};

const rejectLeave = async (id) => {
  try {
    await API.put(`/leave/reject/${id}`);
    loadLeaves(); //  refresh
  } catch (err) {
    console.error(err);
  }
};

return(

<div style={{display:"flex"}}>



<div style={{padding:"20px",width:"100%"}}>



<h2>Leave Requests</h2>

<table border="1" cellPadding="10">

<thead>

<tr>
<th>ID</th>
<th>Employee</th>
<th>Start</th>
<th>End</th>
<th>Status</th>
<th>Action</th>
</tr>

</thead>

<tbody>

{leaves.map(l=>(

<tr key={l.leaveId}>

<td>{l.leaveId}</td>
<td>{l.employeeId}</td>
<td>{l.startDate}</td>
<td>{l.endDate}</td>
<td>{l.status}</td>

<td>
  {l.status === "Pending" && (
    <>
      <button onClick={() => approveLeave(l.leaveId)}>Approve</button>
      <button onClick={() => rejectLeave(l.leaveId)}>Reject</button>
    </>
  )}
</td>
</tr>

))}

</tbody>

</table>

</div>

</div>

)

}

export default Leaves