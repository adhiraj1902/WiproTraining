import { useEffect, useState } from "react";
import API from "../api/api";



function Employees() {

  const [employees, setEmployees] = useState([]);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const [leaveBalance, setLeaveBalance] = useState("");

  const [editId, setEditId] = useState(null);

  useEffect(() => {
    loadEmployees();
  }, []);

  //  GET ALL EMPLOYEES
  const loadEmployees = async () => {
    try {
      const res = await API.get("/Employee"); //  FIXED
      setEmployees(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  //  ADD EMPLOYEE
  const addEmployee = async () => {

    if (!firstName || !lastName || !email || !departmentId || !leaveBalance) {
      alert("Fill all fields");
      return;
    }

    try {

      await API.post("/Employee", {   //  FIXED
        firstName,
        lastName,
        email,
        departmentId: Number(departmentId),
        leaveBalance: Number(leaveBalance)
      });

      alert("Employee Added");

      clearForm();
      loadEmployees();

    } catch (err) {
      console.error(err);
      alert("Error adding employee");
    }
  };

  //  UPDATE EMPLOYEE
  const updateEmployee = async () => {

    try {

      await API.put(`/Employee/${editId}`, {   // FIXED
        employeeId: editId,
        firstName,
        lastName,
        email,
        departmentId: Number(departmentId),
        leaveBalance: Number(leaveBalance)
      });

      alert("Employee Updated");

      clearForm();
      loadEmployees();

    } catch (err) {
      console.error(err);
      alert("Update failed");
    }
  };

  //  DELETE EMPLOYEE
  const deleteEmployee = async (id) => {

    if (!window.confirm("Delete this employee?")) return;

    await API.delete(`/Employee/${id}`); //  FIXED
    loadEmployees();
  };

  // EDIT
  const editEmployee = (emp) => {
    setEditId(emp.employeeId);
    setFirstName(emp.firstName);
    setLastName(emp.lastName);
    setEmail(emp.email);
    setDepartmentId(emp.departmentId);
    setLeaveBalance(emp.leaveBalance);
  };

  // CLEAR
  const clearForm = () => {
    setEditId(null);
    setFirstName("");
    setLastName("");
    setEmail("");
    setDepartmentId("");
    setLeaveBalance("");
  };

  return (

    <div style={{ display: "flex" }}>


      <div style={{ padding: "20px", width: "100%" }}>

        <h2>Employee Management</h2>

        {/* FORM */}
        <div style={{ marginBottom: "20px" }}>

          <input placeholder="First Name"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
          />

          <input placeholder="Last Name"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />

          <input placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <input placeholder="Department ID"
            value={departmentId}
            onChange={(e) => setDepartmentId(e.target.value)}
          />

          <input placeholder="Leave Balance"
            value={leaveBalance}
            onChange={(e) => setLeaveBalance(e.target.value)}
          />

          {editId ? (
            <button onClick={updateEmployee}>Update</button>
          ) : (
            <button onClick={addEmployee}>Add Employee</button>
          )}

        </div>

        {/* TABLE */}
        <table border="1" cellPadding="10">

          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Department</th>
              <th>Leave Balance</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>

            {employees.map((emp) => (

              <tr key={emp.employeeId}>

                <td>{emp.employeeId}</td>

                <td>{emp.firstName} {emp.lastName}</td>

                <td>{emp.email}</td>

                <td>{emp.departmentId}</td>

                <td>{emp.leaveBalance}</td>

                <td>

                  <button onClick={() => editEmployee(emp)}>
                    Edit
                  </button>

                  <button
                    style={{ marginLeft: "10px" }}
                    onClick={() => deleteEmployee(emp.employeeId)}
                  >
                    Delete
                  </button>

                </td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

    </div>
  );
}

export default Employees;