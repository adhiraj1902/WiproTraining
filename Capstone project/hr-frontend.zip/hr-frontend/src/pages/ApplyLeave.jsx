import { useState } from "react";
import API from "../api/api";
import "./applyLeave.css";

function ApplyLeave() {

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const empId = localStorage.getItem("empId");

  const applyLeave = async () => {

    if (!startDate || !endDate) {
      alert("Please select both dates");
      return;
    }

    try {

      await API.post("/leave/request", {
        employeeId: parseInt(empId),
        startDate,
        endDate
      });

      alert("Leave Applied Successfully ✅");

      setStartDate("");
      setEndDate("");

    } catch (err) {
      console.error(err);
      alert("Error applying leave");
    }
  };

  return (
    <div className="apply-container">

      <h1>Apply Leave</h1>

      <div className="apply-card">

        <div className="form-group">
          <label>Start Date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>End Date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />
        </div>

        <button className="apply-btn" onClick={applyLeave}>
          Apply Leave
        </button>

      </div>

    </div>
  );
}

export default ApplyLeave;