import { useEffect, useState } from "react";
import API from "../api/api";
import "./employeeDashboard.css";

function EmployeeDashboard() {

  const [balance, setBalance] = useState(0);
  const [leaves, setLeaves] = useState([]);

  const empId = localStorage.getItem("empId");
  const empName = localStorage.getItem("empName");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // ✅ Leave Balance
      const res1 = await API.get(`/leave/balance/${empId}`);
      setBalance(res1.data);

      // ✅ Leave History
      const res2 = await API.get("/leave");
      const myLeaves = res2.data.filter(l => l.employeeId == empId);
      setLeaves(myLeaves);

    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="dashboard-container">

      {/* MAIN CONTENT ONLY */}
      <div className="main">

        <h1>Welcome, {empName}</h1>

        {/* CARDS */}
        <div className="cards">

          <div className="card purple">
            <h3>{balance}</h3>
            <p>Leave Balance</p>
          </div>

          <div className="card blue">
            <h3>{leaves.length}</h3>
            <p>Total Leaves</p>
          </div>

        </div>

        {/* LEAVE HISTORY */}
        <div className="section">
          <h2>My Leave History</h2>

          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Start</th>
                <th>End</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>
              {leaves.map(l => (
                <tr key={l.leaveId}>
                  <td>{l.leaveId}</td>
                  <td>{l.startDate}</td>
                  <td>{l.endDate}</td>
                  <td className={l.status.toLowerCase()}>
                    {l.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* NOTIFICATIONS */}
        <div className="section">
          <h2>Notifications</h2>

          {leaves.map(l => (
            <div key={l.leaveId} className="notification">
              Leave #{l.leaveId} is <b>{l.status}</b>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}

export default EmployeeDashboard;